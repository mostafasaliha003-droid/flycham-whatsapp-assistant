'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {QuoteJobs}=require('../src/quote-jobs');
const {flyChamAirportRequests}=require('../src/airport-comparison');
const {offerKey}=require('../src/quote-comparison');
const NOW=Date.parse('2090-11-01T10:00:00Z');
const request=(origin='أبوظبي')=>({origin,destination:'دمشق',departureDate:'2090-11-11',tripType:'one_way',returnDate:null,passengers:{adults:1,children:0,infants:0},baggageRequest:{checkedWeightKg:30,source:'default30',requestedByCustomer:false}});
function setup(){const q=new QuoteJobs({now:()=>NOW});q.claim('flycham');q.claim('airarabia');return q;}
function finish(q,j,price){if(price)q.comparisonProgress(j.id,j.lease,{offer:{provider:j.request.provider,request:j.request,timing:{out:{flight:j.request.provider==='flycham'?'XH123':'G9123',departure:'10:00',arrival:'12:00'}},price:{sellingTotal:price,weights:[{kg:30}]}}});return q.completeComparisonChild(j.id,j.lease,{outcome:'done',coverage:[{date:j.request.departureDate,status:price?'confirmed':'no_flights'}]});}
test('Abu Dhabi request compares FlyCham airports and AirArabia airports without an invalid FlyCham Abu Dhabi search',()=>{
 const q=setup(),p=q.enqueueComparison('customer',request(),{compareFlyChamAirports:true,allowAlternatives:false});
 assert.equal(q.claim('airarabia'),null);let j=q.claim('flycham');assert.equal(j.request.origin,'دبي');finish(q,j,'550.00');
 const air=q.claim('airarabia');assert.equal(air.request.origin,'أبوظبي');finish(q,air,'700.00');
 j=q.claim('flycham');assert.equal(j.request.origin,'الشارقة');finish(q,j,'650.00');assert.equal(q.claim('flycham'),null);
 j=q.claim('airarabia');assert.equal(j.request.origin,'الشارقة');const result=finish(q,j,'600.00');
 assert.equal(result.ready,true);assert.equal(result.request.origin,'أبوظبي');assert.equal(result.offers.length,4);assert.match(result.reply,/دبي 550.00 درهم/);assert.match(result.reply,/الشارقة 650.00 درهم/);assert.equal(new Set(result.offers.map(offerKey)).size,4);
});
test('Sharjah exact result displayed before cheaper Dubai alternative, same date and baggage retained',()=>{const q=setup(),r=request('الشارقة'),p=q.enqueueComparison('customer',r,{compareFlyChamAirports:true,allowAlternatives:false});let j=q.claim('flycham');assert.equal(j.request.origin,'الشارقة');assert.equal(j.request.departureDate,r.departureDate);assert.deepEqual(j.request.baggageRequest,r.baggageRequest);finish(q,j,'650.00');j=q.claim('flycham');assert.equal(j.request.origin,'دبي');finish(q,j,'500.00');const result=finish(q,q.claim('airarabia'),'600.00');assert.ok(result.reply.indexOf('650.00')<result.reply.indexOf('500.00'));assert.match(result.reply,/ممكن تكون أوفر/);assert.equal(result.request.origin,'الشارقة');});
test('explicit supplier restriction respected, no extra FlyCham on AirArabia-only request',()=>{const q=setup(),p=q.enqueueComparison('c',request(),{providers:['airarabia'],compareFlyChamAirports:true});assert.equal(p.statuses.length,2);assert.ok(q.claim('airarabia'));assert.ok(p.statuses.every(x=>x.provider==='airarabia'));assert.equal(q.claim('flycham'),null);assert.deepEqual(flyChamAirportRequests(request('دمشق')),[]);});
test('airport identity prevents identical flight/time collapsing offers',()=>{const a={provider:'flycham',request:request('الشارقة'),timing:{out:{flight:'XH123',departure:'10:00'}}},b=structuredClone(a);b.request.origin='دبي';assert.notEqual(offerKey(a),offerKey(b));});
test('fresh general inquiry includes requested Sharjah then Dubai, and the catalog plans Dubai FlyCham routes',()=>{
 const {FareCatalog}=require('../src/fare-catalog'),c=new FareCatalog({now:()=>NOW});
 for(const [origin,price]of [['الشارقة','650.00'],['دبي','500.00']])c.records.set(origin,{provider:'flycham',request:request(origin),checkedAt:NOW,timing:{out:{flight:'XH123',departure:'10:00',arrival:'12:00'}},price:{sellingTotal:price,weights:[{kg:30}],voucherValue:'10.00'}});
 const reply=c.reply({origin:'الشارقة',destinationCountry:'سوريا'});assert.ok(reply.includes('500.00'));assert.ok(reply.indexOf('650.00')<reply.indexOf('500.00'));assert.ok(c.plan('flycham').some(x=>x.request.origin==='دبي'));assert.ok(!c.plan('airarabia').some(x=>x.request.origin==='دبي'));
});
