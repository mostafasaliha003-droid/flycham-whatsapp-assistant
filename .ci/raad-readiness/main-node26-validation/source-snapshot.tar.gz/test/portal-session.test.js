'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { PortalSession, randomHeartbeatDate, HEARTBEAT_IDLE_MS } = require('../src/portal-session');
function fixture() {
  let now = 0, authenticated = true, logins = 0, heartbeats = 0;
  const adapter = { isAuthenticated: async () => authenticated, signIn: async () => { logins++; authenticated = true; }, refreshProtectedPage: async (...args) => { assert.equal(args.length, 0); heartbeats++; } };
  const session = new PortalSession(adapter, { now: () => now, random: () => 0, idleMs: 120000, checkMs: 1000 });
  return { session, adapter, advance: n => { now += n; }, expire: () => { authenticated = false; }, stats: () => ({ logins, heartbeats }) };
}
test('refreshes the protected page on an idle heartbeat without a synthetic search', async () => {
  const f = fixture();
  assert.equal(await f.session.heartbeat(), false);
  f.advance(120000);
  assert.equal(await f.session.heartbeat(), true);
  await f.session.tail;
  assert.equal(await f.session.heartbeat(), false);
  assert.deepEqual(f.stats(), { logins: 0, heartbeats: 1 });
  await f.session.stop();
});
test('readiness requires successful protected initialization and expires when stale', async () => {
  const f = fixture();
  assert.equal(f.session.isReady(), false);
  await f.session.initialize();
  assert.equal(f.session.isReady(), true);
  assert.equal(f.session.healthStatus().lastSuccessfulActivityAt, 0);
  f.advance(122001);
  assert.equal(f.session.isReady(), false);
  assert.equal(f.session.healthStatus().state, 'stale');
  await f.session.stop();
});
test('failed work and failed discovery do not postpone the protected heartbeat', async () => {
  const f = fixture();
  await f.session.initialize();
  f.advance(119000);
  await assert.rejects(f.session.run(async () => { throw Error('unverified fare'); }));
  await f.session.run(async () => ({ outcome: 'failed' }));
  await f.session.tail;
  assert.equal(f.session.lastSuccessfulActivityAt, 0);
  f.advance(1000);
  assert.equal(await f.session.heartbeat(), true);
  assert.equal(f.stats().heartbeats, 2);
  await f.session.stop();
});
test('verified adapter activity keeps a long quote healthy without an idle navigation', async () => {
  const f = fixture();
  await f.session.initialize();
  f.advance(121000);
  f.adapter.onAuthenticatedActivity();
  assert.equal(f.session.isReady(), true);
  assert.equal(await f.session.heartbeat(), false);
  await f.session.stop();
});
test('one transient refresh failure withdraws readiness and retries once without repeated credentials', async () => {
  const f = fixture(), events = [];
  f.session.report = event => events.push(event);
  await f.session.initialize();
  let attempts = 0;
  f.adapter.refreshProtectedPage = async () => { if (++attempts === 1) throw Object.assign(Error('sensitive network detail'), { name: 'TimeoutError' }); };
  f.advance(120000);
  assert.equal(await f.session.heartbeat(), false);
  assert.equal(f.session.isReady(), false);
  f.advance(59999);
  assert.equal(await f.session.heartbeat(), false);
  f.advance(1);
  assert.equal(await f.session.heartbeat(), true);
  assert.equal(f.session.isReady(), true);
  assert.equal(f.stats().logins, 0);
  assert.ok(events.includes('PORTAL_PROTECTED_REFRESH_RETRY_SCHEDULED'));
  assert.ok(!events.join(' ').includes('sensitive'));
  await f.session.stop();
});
test('a second transient refresh failure terminates the bounded retry', async () => {
  const f = fixture();
  await f.session.initialize();
  let attempts = 0;
  f.adapter.refreshProtectedPage = async () => { attempts++; throw Object.assign(Error('timeout'), { name: 'TimeoutError' }); };
  f.advance(120000);
  assert.equal(await f.session.heartbeat(), false);
  f.advance(60000);
  await assert.rejects(f.session.heartbeat(), /timeout/);
  assert.equal(attempts, 2);
  assert.equal(f.session.isReady(), false);
  await f.session.stop();
});
test('a security challenge never enters the transient retry path', async () => {
  const f = fixture();
  await f.session.initialize();
  f.adapter.refreshProtectedPage = async () => { throw Error('FLYCHAM_MANUAL_VERIFICATION'); };
  f.advance(120000);
  await assert.rejects(f.session.heartbeat(), /MANUAL_VERIFICATION/);
  assert.equal(f.session.authBlocked, true);
  assert.equal(f.session.isReady(), false);
  f.advance(60000);
  assert.equal(await f.session.heartbeat(), false);
  await f.session.stop();
});
test('an existing verification challenge uses operator recovery without submitting credentials', async () => {
  const f = fixture();
  f.expire();
  let challenges = 0;
  f.adapter.hasVerificationChallenge = async () => true;
  f.adapter.resumeVerification = async () => { challenges++; f.adapter.isAuthenticated = async () => true; };
  await f.session.initialize();
  assert.equal(challenges, 1);
  assert.equal(f.stats().logins, 0);
  assert.equal(f.session.isReady(), true);
  await f.session.stop();
});
test('uses a randomized date 30 to 90 days in the future and defaults to a 15-minute interval', () => {
  assert.equal(HEARTBEAT_IDLE_MS, 15 * 60 * 1000);
  const now = () => Date.UTC(2026, 0, 1);
  const earliest = new Date(now() + 30 * 86400000);
  const latest = new Date(now() + 90 * 86400000);
  const toDate = value => { const [day, month, year] = value.split('/').map(Number); return Date.UTC(year, month - 1, day); };
  assert.equal(toDate(randomHeartbeatDate(now, () => 0)), Date.UTC(earliest.getUTCFullYear(), earliest.getUTCMonth(), earliest.getUTCDate()));
  assert.equal(toDate(randomHeartbeatDate(now, () => 0.999999)), Date.UTC(latest.getUTCFullYear(), latest.getUTCMonth(), latest.getUTCDate()));
});
test('serializes quotes and does not reset the search during an active quote', async () => {
  const f = fixture();
  let release, entered;
  const started = new Promise(resolve => { entered = resolve; });
  const gate = new Promise(resolve => { release = resolve; });
  const events = [];
  const first = f.session.run(async () => { events.push('first'); entered(); await gate; events.push('done'); });
  await started;
  const second = f.session.run(async () => { events.push('second'); });
  f.advance(120000);
  assert.equal(await f.session.heartbeat(), false);
  release();
  await Promise.all([first, second]);
  assert.deepEqual(events, ['first', 'done', 'second']);
  assert.equal(f.stats().heartbeats, 0);
  await f.session.stop();
});
test('reauthenticates an expired session and verifies it before executing a quote', async () => {
  const f = fixture();
  f.expire();
  assert.equal(await f.session.run(async () => 'quote'), 'quote');
  assert.equal(f.stats().logins, 1);
  await f.session.stop();
});
test('stops repeated authentication attempts after a rejected login', async () => {
  const f = fixture();
  f.expire();
  let attempts = 0, tasks = 0;
  f.adapter.signIn = async () => { attempts++; throw new Error('rejected'); };
  await assert.rejects(f.session.run(async () => { tasks++; }));
  f.advance(500000);
  await assert.rejects(f.session.run(async () => { tasks++; }));
  assert.equal(attempts, 1);
  assert.equal(tasks, 0);
  await f.session.stop();
});
test('ordinary sign-in navigation timeout preserves its type and retries once on initialization', async () => {
  const f = fixture(),events=[];
  f.expire();f.session.report=event=>events.push(event);f.session.pause=async()=>{};
  let attempts=0,authenticated=false;
  f.adapter.isAuthenticated=async()=>authenticated;
  f.adapter.signIn=async()=>{if(++attempts===1)throw Object.assign(Error('private selector detail'),{name:'PortalError',stage:'LOGIN_FORM',reason:'TIMEOUT'});authenticated=true;};
  await f.session.initialize();
  assert.equal(attempts,2);assert.equal(f.session.authBlocked,false);assert.equal(f.session.isReady(),true);
  assert.ok(events.includes('PORTAL_PROTECTED_REFRESH_RETRY_SCHEDULED'));assert.ok(!events.join(' ').includes('private'));await f.session.stop();
});
test('a network failure during reauthentication uses bounded heartbeat retry without blocking credentials', async () => {
  const f=fixture();await f.session.initialize();f.expire();let attempts=0,authenticated=false;
  f.adapter.isAuthenticated=async()=>authenticated;
  f.adapter.signIn=async()=>{if(++attempts===1)throw Object.assign(Error('private network details'),{name:'PortalError',stage:'LOGIN_SUBMIT',reason:'NETWORK'});authenticated=true;};
  f.advance(120000);assert.equal(await f.session.heartbeat(),false);assert.equal(f.session.authBlocked,false);assert.equal(f.session.isReady(),false);
  f.advance(59999);assert.equal(await f.session.heartbeat(),false);assert.equal(attempts,1);
  f.advance(1);assert.equal(await f.session.heartbeat(),true);assert.equal(attempts,2);assert.equal(f.session.isReady(),true);await f.session.stop();
});
test('two sign-in timeouts terminate the heartbeat retry and never execute protected work', async () => {
  const f=fixture();await f.session.initialize();f.expire();let attempts=0,tasks=0;
  f.adapter.signIn=async()=>{attempts++;throw Object.assign(Error('timeout'),{name:'TimeoutError'});};
  f.adapter.refreshProtectedPage=async()=>{tasks++;};f.advance(120000);assert.equal(await f.session.heartbeat(),false);f.advance(60000);
  await assert.rejects(f.session.heartbeat(),/timeout/);assert.equal(attempts,2);assert.equal(tasks,0);assert.equal(f.session.authBlocked,false);assert.equal(f.session.state,'unavailable');await f.session.stop();
});
test('verification timeout and typed security failures never retry sign-in despite a transient flag', async () => {
  for(const reason of ['CAPTCHA','BAD_CREDENTIALS','VERIFICATION_REJECTED']){
    const f=fixture();f.expire();let attempts=0;f.session.pause=async()=>{};
    f.adapter.signIn=async()=>{attempts++;throw Object.assign(Error('supplier response'),{reason,transient:true});};
    await assert.rejects(f.session.initialize(),/operator review/);assert.equal(attempts,1);assert.equal(f.session.authBlocked,true);await f.session.stop();
  }
  const f=fixture();f.expire();let verifies=0;f.session.pause=async()=>{};f.adapter.hasVerificationChallenge=async()=>true;
  f.adapter.resumeVerification=async()=>{verifies++;throw Object.assign(Error('DOM timeout'),{name:'TimeoutError'});};
  await assert.rejects(f.session.initialize(),/operator review/);assert.equal(verifies,1);assert.equal(f.stats().logins,0);assert.equal(f.session.authBlocked,true);await f.session.stop();
});
test('graceful stop drains current work and rejects new jobs', async () => {
  const f = fixture();
  let release, entered;
  const started = new Promise(resolve => { entered = resolve; });
  const gate = new Promise(resolve => { release = resolve; });
  const job = f.session.run(async () => { entered(); await gate; });
  await started;
  const stopped = f.session.stop();
  await assert.rejects(f.session.run(async () => {}));
  release(); await job; await stopped;
  assert.equal(await f.session.heartbeat(), false);
});
